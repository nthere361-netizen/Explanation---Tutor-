/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroInput } from './components/HeroInput';
import { LearningFlowVisual } from './components/LearningFlowVisual';
import { HeroIllustration } from './components/HeroIllustration';
import { ExplanationWorkspace } from './components/ExplanationWorkspace';
import { MyMaterialsView } from './components/MyMaterialsView';
import { CodeTutorView } from './components/CodeTutorView';
import { LearningPathView } from './components/LearningPathView';
import { DashboardView } from './components/DashboardView';
import { SettingsView } from './components/SettingsView';
import { ExplanationData, ExplanationLevel, UserPreferences } from './types';
import { PRESET_EXPLANATIONS } from './data/mockData';
import { fetchExplanation } from './services/tutorService';
import { Sparkles, Compass, ArrowRight, ShieldCheck, Heart } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'explain' | 'materials' | 'code-tutor' | 'paths' | 'settings'>('home');
  const [activeExplanation, setActiveExplanation] = useState<ExplanationData>(PRESET_EXPLANATIONS['explain photosynthesis']);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  
  const [recentQuestions, setRecentQuestions] = useState([
    { id: '1', query: 'Explain photosynthesis', level: 'beginner', timestamp: Date.now() - 3600000 },
    { id: '2', query: 'What is an API?', level: 'beginner', timestamp: Date.now() - 7200000 },
    { id: '3', query: 'Explain recursion', level: 'beginner', timestamp: Date.now() - 86400000 },
  ]);

  const [savedTopics, setSavedTopics] = useState([
    { 
      id: 'photosynthesis', 
      title: 'Photosynthesis & The Calvin Cycle', 
      summary: '6CO2 + 6H2O -> C6H12O6 + 6O2. Photolysis splits water, yielding O2 and ATP.', 
      savedAt: Date.now() - 10000000 
    }
  ]);

  const [preferences, setPreferences] = useState<UserPreferences>({
    defaultLevel: 'beginner',
    speechSpeed: 1.0,
    voiceEnabled: true,
    explanationStyle: 'analogy',
    reducedMotion: false
  });

  // Handles requesting an explanation for a topic
  const handleExplain = async (query: string, levelOverride?: ExplanationLevel, mode?: string) => {
    setIsLoading(true);
    setLoadingStep('Understanding your question…');

    // Progressive loading steps for realism and feedback
    const t1 = setTimeout(() => {
      setLoadingStep('Building a simple explanation…');
    }, 450);

    const t2 = setTimeout(() => {
      setLoadingStep('Preparing visual examples…');
    }, 900);

    try {
      const targetLevel = levelOverride || preferences.defaultLevel;
      const result = await fetchExplanation(query, targetLevel, mode);
      
      clearTimeout(t1);
      clearTimeout(t2);
      
      setActiveExplanation(result);
      setCurrentTab('explain');

      // Update recent questions
      setRecentQuestions((prev) => [
        { id: 'q-' + Date.now(), query, level: targetLevel, timestamp: Date.now() },
        ...prev.filter(q => q.query.toLowerCase() !== query.toLowerCase()).slice(0, 7)
      ]);
    } catch (err) {
      console.error('Explanation request failed:', err);
    } finally {
      clearTimeout(t1);
      clearTimeout(t2);
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  const handleLevelChange = (level: ExplanationLevel) => {
    if (activeExplanation) {
      handleExplain(activeExplanation.topic, level);
    }
  };

  const handleTutorAction = (action: 'simpler' | 'visual' | 'example' | 'stepByStep' | 'deeper') => {
    if (activeExplanation) {
      handleExplain(activeExplanation.topic, activeExplanation.level, action);
    }
  };

  const handleToggleSave = () => {
    if (!activeExplanation) return;
    const exists = savedTopics.some(t => t.id === activeExplanation.id || t.title.toLowerCase() === activeExplanation.topic.toLowerCase());
    if (exists) {
      setSavedTopics(savedTopics.filter(t => t.id !== activeExplanation.id && t.title.toLowerCase() !== activeExplanation.topic.toLowerCase()));
    } else {
      setSavedTopics([
        {
          id: activeExplanation.id,
          title: activeExplanation.topic,
          summary: activeExplanation.simpleExplanation.slice(0, 120) + '...',
          savedAt: Date.now()
        },
        ...savedTopics
      ]);
    }
  };

  const isCurrentSaved = activeExplanation 
    ? savedTopics.some(t => t.id === activeExplanation.id || t.title.toLowerCase() === activeExplanation.topic.toLowerCase())
    : false;

  const handleResetData = () => {
    setRecentQuestions([]);
    setSavedTopics([]);
    setActiveExplanation(PRESET_EXPLANATIONS['explain photosynthesis']);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Navbar */}
      <Navbar 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        hasActiveExplanation={!!activeExplanation} 
      />

      {/* Main Content View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-7">
        {/* HOME VIEW */}
        {currentTab === 'home' && (
          <div className="space-y-8 sm:space-y-10">
            {/* Hero Section */}
            <section className="text-center pt-2 sm:pt-4 pb-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50/90 border border-indigo-200/70 text-xs font-semibold text-indigo-700 mb-4 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>AI that helps people understand, not just gives answers</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12] max-w-3xl mx-auto">
                Make difficult topics <br className="hidden sm:inline" />
                <span className="bg-linear-to-r from-indigo-600 via-purple-600 to-teal-600 bg-clip-text text-transparent">
                  easy to understand.
                </span>
              </h1>

              <p className="mt-3 sm:mt-4 text-sm sm:text-base text-slate-600 max-w-xl mx-auto font-normal leading-relaxed">
                Ask anything. Get a simple explanation, visual examples, practice questions, and deeper learning when you’re ready.
              </p>

              {/* Primary Interactive Question Input */}
              <div className="mt-6">
                <HeroInput 
                  onExplain={handleExplain} 
                  isLoading={isLoading} 
                  loadingStep={loadingStep} 
                />
              </div>
            </section>

            {/* Learning Flow Visualization */}
            <section>
              <LearningFlowVisual />
            </section>

            {/* AI Visual / Hero Illustration */}
            <section>
              <HeroIllustration />
            </section>

            {/* Dashboard Section */}
            <section className="pt-2">
              <div className="flex items-center justify-between mb-3.5">
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                  Your Learning Dashboard
                </h2>
                <span className="text-xs font-semibold text-slate-600">
                  Quick Resume & Vault
                </span>
              </div>
              <DashboardView 
                recentQuestions={recentQuestions} 
                savedTopics={savedTopics} 
                onSelectTopic={(t) => handleExplain(t)}
                onNavigateTab={(tab) => setCurrentTab(tab)}
              />
            </section>
          </div>
        )}

        {/* EXPLAIN WORKSPACE VIEW */}
        {currentTab === 'explain' && (
          <div className="space-y-6">
            {/* Quick search bar inside workspace */}
            <div className="max-w-4xl mx-auto">
              <HeroInput 
                onExplain={handleExplain} 
                isLoading={isLoading} 
                loadingStep={loadingStep} 
              />
            </div>

            {activeExplanation ? (
              <ExplanationWorkspace 
                data={activeExplanation} 
                onLevelChange={handleLevelChange}
                onTutorAction={handleTutorAction}
                onSelectTopic={(t) => handleExplain(t)}
                isSaved={isCurrentSaved}
                onToggleSave={handleToggleSave}
              />
            ) : (
              <div className="max-w-xl mx-auto p-10 text-center bg-white rounded-2xl border border-slate-200 shadow-xs">
                <p className="text-slate-500 text-sm">
                  “Start with something you’re curious about.”
                </p>
              </div>
            )}
          </div>
        )}

        {/* MY MATERIALS VIEW */}
        {currentTab === 'materials' && (
          <MyMaterialsView onLearnFromTopic={(topic) => handleExplain(topic)} />
        )}

        {/* CODE TUTOR VIEW */}
        {currentTab === 'code-tutor' && (
          <CodeTutorView />
        )}

        {/* LEARNING PATHS VIEW */}
        {currentTab === 'paths' && (
          <LearningPathView onStartTopic={(prompt) => handleExplain(prompt)} />
        )}

        {/* SETTINGS VIEW */}
        {currentTab === 'settings' && (
          <SettingsView 
            preferences={preferences}
            onUpdatePreferences={(updated) => setPreferences({ ...preferences, ...updated })}
            onResetData={handleResetData}
            onLaunchDemoPreset={(t) => handleExplain(t)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 bg-white/80 backdrop-blur-xs mt-12 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
            <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-[10px] shadow-xs">
              ET
            </span>
            <span>Explanation Tutor</span>
            <span className="text-slate-300 font-normal">|</span>
            <span className="text-slate-600 font-medium text-[11px]">“AI that helps people understand, not just gives answers”</span>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium text-slate-600">
            <button onClick={() => setCurrentTab('home')} className="hover:text-indigo-600 transition-colors">Home</button>
            <button onClick={() => setCurrentTab('explain')} className="hover:text-indigo-600 transition-colors">Explain</button>
            <button onClick={() => setCurrentTab('materials')} className="hover:text-indigo-600 transition-colors">My Materials</button>
            <button onClick={() => setCurrentTab('code-tutor')} className="hover:text-indigo-600 transition-colors">Code Tutor</button>
            <button onClick={() => setCurrentTab('paths')} className="hover:text-indigo-600 transition-colors">Learning Paths</button>
            <button onClick={() => setCurrentTab('settings')} className="hover:text-indigo-600 transition-colors">Settings</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
