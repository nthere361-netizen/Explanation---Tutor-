import React, { useState } from 'react';
import { CodeTutorResponse } from '../types';
import { SAMPLE_CODE_TUTOR_CASES } from '../data/mockData';
import { debugCodeWithTutor } from '../services/tutorService';
import { 
  Code2, 
  Play, 
  Sparkles, 
  Check, 
  Copy, 
  AlertTriangle, 
  HelpCircle, 
  CheckCircle2, 
  RefreshCw, 
  BookOpen, 
  Terminal,
  ChevronRight,
  Layers
} from 'lucide-react';

export const CodeTutorView: React.FC = () => {
  const [selectedCaseIdx, setSelectedCaseIdx] = useState<number>(0);
  const [code, setCode] = useState<string>(SAMPLE_CODE_TUTOR_CASES[0].code);
  const [language, setLanguage] = useState<string>(SAMPLE_CODE_TUTOR_CASES[0].language);
  const [errorDesc, setErrorDesc] = useState<string>(SAMPLE_CODE_TUTOR_CASES[0].errorDescription);
  const [result, setResult] = useState<CodeTutorResponse | null>(SAMPLE_CODE_TUTOR_CASES[0].response);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [showSolution, setShowSolution] = useState<boolean>(false);
  const [userTryAnswer, setUserTryAnswer] = useState<string>('');
  const [challengeFeedback, setChallengeFeedback] = useState<string | null>(null);

  const handleSelectCase = (idx: number) => {
    setSelectedCaseIdx(idx);
    const item = SAMPLE_CODE_TUTOR_CASES[idx];
    setCode(item.code);
    setLanguage(item.language);
    setErrorDesc(item.errorDescription);
    setResult(item.response);
    setShowSolution(false);
    setUserTryAnswer(item.response.tryItYourself.starterCode);
    setChallengeFeedback(null);
  };

  const handleRunTutor = async () => {
    setIsLoading(true);
    setShowSolution(false);
    setChallengeFeedback(null);
    try {
      const resp = await debugCodeWithTutor(code, language, errorDesc);
      setResult(resp);
      setUserTryAnswer(resp.tryItYourself.starterCode);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCode = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.correctedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCheckChallenge = () => {
    if (!result) return;
    if (userTryAnswer.includes('None') || userTryAnswer.includes('let ') || userTryAnswer.includes('<= 1') || userTryAnswer.includes('if')) {
      setChallengeFeedback('correct');
    } else {
      setChallengeFeedback('incorrect');
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-purple-50 text-purple-700 border border-purple-100">
              Computational Logic Tutor
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2 tracking-tight">
              Code Tutor: Understand Why Code Breaks
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Never copy-paste blind fixes. Understand the underlying execution mechanics, memory lifecycle, and scope invariants.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 hidden sm:inline">
              Sample Scenarios:
            </span>
            <div className="flex items-center gap-1.5">
              {SAMPLE_CODE_TUTOR_CASES.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectCase(idx)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                    selectedCaseIdx === idx
                      ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  Scenario {idx + 1}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Code Input & Editor Deck */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8 rounded-2xl bg-slate-950 border border-slate-800 shadow-inner overflow-hidden flex flex-col">
            {/* Editor Top Bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <span className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
                </div>
                <span className="text-slate-400 font-mono ml-2">code_snippet.{language === 'python' ? 'py' : language === 'javascript' ? 'js' : 'cpp'}</span>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="bg-slate-800 text-slate-200 text-xs rounded-lg px-2 py-1 border border-slate-700 focus:outline-none"
                >
                  <option value="python">Python</option>
                  <option value="javascript">JavaScript</option>
                  <option value="typescript">TypeScript</option>
                  <option value="cpp">C++</option>
                  <option value="java">Java</option>
                </select>
              </div>
            </div>

            {/* Code Input Textarea */}
            <textarea
              rows={8}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full p-4 bg-transparent text-emerald-400 font-mono text-xs sm:text-sm leading-relaxed focus:outline-none resize-none selection:bg-purple-900/50"
              placeholder="Paste or write problematic code here..."
            />
          </div>

          {/* Right description & trigger */}
          <div className="lg:col-span-4 flex flex-col justify-between space-y-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5 uppercase tracking-wider">
                Bug / Error Symptom
              </label>
              <textarea
                rows={4}
                value={errorDesc}
                onChange={(e) => setErrorDesc(e.target.value)}
                placeholder="What error or unexpected behavior did you observe?"
                className="w-full p-3 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <button
              onClick={handleRunTutor}
              disabled={isLoading || !code.trim()}
              className="w-full py-3 rounded-xl font-bold text-sm bg-purple-600 hover:bg-purple-700 active:scale-98 text-white shadow-md shadow-purple-200 flex items-center justify-center gap-2 transition-all"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Deconstructing Code Mechanics...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Explain Why & Fix</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Tutor Response Sections */}
      {result && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* 1. WHAT'S WRONG? & 2. WHY? */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* WHAT'S WRONG */}
            <div className="bg-white rounded-2xl p-6 border border-rose-200/80 shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-rose-700">
                  What's Wrong?
                </h3>
              </div>
              <p className="text-sm text-slate-800 leading-relaxed font-medium">
                {result.whatsWrong}
              </p>
            </div>

            {/* WHY? */}
            <div className="bg-white rounded-2xl p-6 border border-indigo-200/80 shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 border border-indigo-200">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                  Why Does This Happen?
                </h3>
              </div>
              <p className="text-sm text-slate-800 leading-relaxed">
                {result.why}
              </p>
            </div>
          </div>

          {/* 3. CORRECTED CODE & 4. WHAT CHANGED? */}
          <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Corrected Code
                </h3>
              </div>
              <button
                onClick={handleCopyCode}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Fix'}</span>
              </button>
            </div>

            <div className="rounded-xl bg-slate-950 p-4 font-mono text-xs sm:text-sm text-slate-100 overflow-x-auto border border-slate-800 leading-relaxed">
              <pre>{result.correctedCode}</pre>
            </div>

            {/* WHAT CHANGED? */}
            <div className="mt-5 pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                What Changed?
              </h4>
              <ul className="space-y-2">
                {result.whatChanged.map((change, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
                    <span>{change}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* 5. LEARN THIS CONCEPT */}
          <div className="bg-linear-to-r from-purple-50/70 to-indigo-50/70 rounded-2xl p-6 border border-purple-200/70 shadow-xs">
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 rounded-lg bg-purple-100 text-purple-700 border border-purple-200">
                <BookOpen className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-purple-800">
                Learn This Concept: {result.learnThisConcept.concept}
              </h3>
            </div>
            <p className="text-sm text-slate-700 leading-relaxed mb-3">
              {result.learnThisConcept.explanation}
            </p>
            <div className="p-3 rounded-xl bg-white border border-purple-200 text-xs font-bold text-purple-900 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-600 shrink-0" />
              <span>{result.learnThisConcept.ruleOfThumb}</span>
            </div>
          </div>

          {/* 6. TRY IT YOURSELF (Interactive Challenge) */}
          <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-teal-50 text-teal-700 border border-teal-200">
                  <Terminal className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800">
                  Try It Yourself: Mini Challenge
                </h3>
              </div>
              <button
                onClick={() => setShowSolution(!showSolution)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 underline"
              >
                {showSolution ? 'Hide Solution' : 'Reveal Solution'}
              </button>
            </div>

            <p className="text-sm font-semibold text-slate-800 mb-3">
              {result.tryItYourself.prompt}
            </p>

            <textarea
              rows={4}
              value={userTryAnswer}
              onChange={(e) => setUserTryAnswer(e.target.value)}
              className="w-full p-3 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs sm:text-sm border border-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 mb-3"
            />

            <div className="flex items-center justify-between">
              <button
                onClick={handleCheckChallenge}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-600 hover:bg-teal-700 text-white shadow-xs transition-all"
              >
                Check Understanding
              </button>

              {challengeFeedback === 'correct' && (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Excellent! You applied the core concept correctly!</span>
                </span>
              )}
              {challengeFeedback === 'incorrect' && (
                <span className="text-xs font-bold text-amber-600 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Keep going! Review the rule of thumb above.</span>
                </span>
              )}
            </div>

            {showSolution && (
              <div className="mt-4 p-4 rounded-xl bg-slate-100 border border-slate-200 font-mono text-xs text-slate-800">
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Reference Solution:
                </div>
                <pre>{result.tryItYourself.solutionCode}</pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
