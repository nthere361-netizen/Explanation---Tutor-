import React, { useState } from 'react';
import { StudyMaterial } from '../types';
import { SAMPLE_STUDY_MATERIALS } from '../data/mockData';
import { 
  UploadCloud, 
  FileText, 
  Sparkles, 
  CheckCircle, 
  ArrowRight, 
  Trash2, 
  Clock, 
  HardDrive, 
  BookOpen, 
  AlertCircle,
  FileCode,
  Loader2
} from 'lucide-react';

interface MyMaterialsViewProps {
  onLearnFromTopic: (topic: string) => void;
}

export const MyMaterialsView: React.FC<MyMaterialsViewProps> = ({ onLearnFromTopic }) => {
  const [materials, setMaterials] = useState<StudyMaterial[]>(SAMPLE_STUDY_MATERIALS);
  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(SAMPLE_STUDY_MATERIALS[0]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [customTitle, setCustomTitle] = useState('');
  const [customText, setCustomText] = useState('');
  const [showPasteModal, setShowPasteModal] = useState(false);

  const handleSimulatedUpload = (file: File) => {
    setIsUploading(true);
    setUploadProgress(20);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval);
          setTimeout(() => {
            const newMat: StudyMaterial = {
              id: 'mat-' + Date.now(),
              title: file.name,
              type: file.name.endsWith('.pdf') ? 'pdf' : file.name.endsWith('.py') || file.name.endsWith('.js') ? 'code' : 'notes',
              size: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
              date: 'Just now',
              summary: `Extracted core concepts from ${file.name}. Prepared for structured cognitive tutoring.`,
              keyConcepts: [
                'First principles and core mechanisms',
                'Input-output relationships',
                'Common points of failure',
                'Review and practice questions'
              ],
              content: `Extracted content from ${file.name}. This document covers key mechanisms and explanations.`,
              recommendedQuestions: [
                `Explain the main takeaway of ${file.name}`,
                `How would you test someone's understanding of this topic?`,
                `What is a real-world analogy for this material?`
              ]
            };
            setMaterials([newMat, ...materials]);
            setSelectedMaterial(newMat);
            setIsUploading(false);
            setUploadProgress(0);
          }, 600);
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  const handleCreateFromText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customText.trim()) return;

    const newMat: StudyMaterial = {
      id: 'mat-' + Date.now(),
      title: customTitle.trim() || 'Custom Lecture Notes',
      type: 'notes',
      size: `${(customText.length / 1024).toFixed(1)} KB`,
      date: 'Just now',
      summary: customText.slice(0, 160) + '...',
      keyConcepts: [
        'Main concept definition & boundaries',
        'Direct relationship to practice problems',
        'Key vocabulary & terminology'
      ],
      content: customText,
      recommendedQuestions: [
        `Explain the core concept in ${customTitle || 'these notes'}`,
        'What is an everyday analogy for this?'
      ]
    };

    setMaterials([newMat, ...materials]);
    setSelectedMaterial(newMat);
    setCustomTitle('');
    setCustomText('');
    setShowPasteModal(false);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Header & Flow Indicator */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-indigo-50 text-indigo-700 border border-indigo-100">
              Personal Study Vault
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2 tracking-tight">
              My Study Materials
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Upload your textbook chapters, PDFs, lecture slides, or notes to generate structured explanations.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPasteModal(true)}
              className="px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
            >
              Paste Raw Notes
            </button>
          </div>
        </div>

        {/* Visual Flow: UPLOAD → ANALYZE → UNDERSTAND → LEARN */}
        <div className="mt-6 pt-2">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            <div className="p-2.5 rounded-xl bg-indigo-50/60 border border-indigo-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 block">Step 1</span>
              <span className="text-xs font-bold text-slate-800">UPLOAD</span>
            </div>
            <div className="p-2.5 rounded-xl bg-purple-50/60 border border-purple-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 block">Step 2</span>
              <span className="text-xs font-bold text-slate-800">ANALYZE</span>
            </div>
            <div className="p-2.5 rounded-xl bg-teal-50/60 border border-teal-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 block">Step 3</span>
              <span className="text-xs font-bold text-slate-800">UNDERSTAND</span>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50/60 border border-emerald-100">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 block">Step 4</span>
              <span className="text-xs font-bold text-slate-800">LEARN</span>
            </div>
          </div>
        </div>
      </div>

      {/* Upload Dropzone */}
      <div className="bg-white rounded-2xl border-2 border-dashed border-slate-300 hover:border-indigo-400 p-6 sm:p-8 text-center transition-colors relative group">
        <input
          type="file"
          accept=".pdf,.txt,.md,.docx,.py,.js,.java"
          onChange={(e) => {
            if (e.target.files && e.target.files[0]) {
              handleSimulatedUpload(e.target.files[0]);
            }
          }}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />

        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
          <UploadCloud className="w-6 h-6" />
        </div>

        <h3 className="text-base font-bold text-slate-900 mb-1">
          Drop your lecture slides, PDFs, or notes here
        </h3>
        <p className="text-xs text-slate-500 mb-3">
          Supports PDF, Markdown, Text, Code files up to 25MB
        </p>
        <span className="inline-block px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
          Browse Files
        </span>

        {/* Upload progress state */}
        {isUploading && (
          <div className="mt-4 pt-4 border-t border-slate-100 max-w-xs mx-auto">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
              <span>Analyzing Document...</span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-600 transition-all duration-200" 
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Materials Explorer: Left list + Right details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Material list */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Loaded Materials ({materials.length})
            </span>
          </div>

          <div className="space-y-2.5">
            {materials.map((mat) => {
              const isSelected = selectedMaterial?.id === mat.id;
              return (
                <button
                  key={mat.id}
                  onClick={() => setSelectedMaterial(mat)}
                  className={`w-full p-4 rounded-xl text-left border transition-all duration-150 flex items-start gap-3 ${
                    isSelected
                      ? 'bg-indigo-50/90 border-indigo-300 ring-2 ring-indigo-400/20 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className={`p-2 rounded-lg shrink-0 ${
                    mat.type === 'pdf' ? 'bg-rose-50 text-rose-600' :
                    mat.type === 'code' ? 'bg-purple-50 text-purple-600' :
                    'bg-indigo-50 text-indigo-600'
                  }`}>
                    {mat.type === 'code' ? <FileCode className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className={`text-xs sm:text-sm font-bold truncate ${
                      isSelected ? 'text-indigo-900' : 'text-slate-800'
                    }`}>
                      {mat.title}
                    </h4>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-600">
                      <span>{mat.size}</span>
                      <span>•</span>
                      <span>{mat.date}</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Material Deep View */}
        <div className="lg:col-span-2">
          {selectedMaterial ? (
            <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200/90 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200/60">
                    Extracted Curriculum
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
                    {selectedMaterial.title}
                  </h3>
                </div>

                <button
                  onClick={() => onLearnFromTopic(selectedMaterial.recommendedQuestions[0] || selectedMaterial.title)}
                  className="px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1.5 shadow-sm shadow-indigo-200 transition-all hover:scale-102"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Launch Tutor on Topic</span>
                </button>
              </div>

              {/* Summary */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Conceptual Summary
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                  {selectedMaterial.summary}
                </p>
              </div>

              {/* Key Concepts */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Identified Core Concepts
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedMaterial.keyConcepts.map((concept, i) => (
                    <div key={i} className="p-3 rounded-xl bg-indigo-50/40 border border-indigo-100 flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                      <span className="text-xs font-medium text-slate-800 leading-snug">
                        {concept}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Questions to Ask Tutor */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Recommended Tutor Prompts
                </h4>
                <div className="space-y-2">
                  {selectedMaterial.recommendedQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => onLearnFromTopic(q)}
                      className="w-full p-3 rounded-xl text-left bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-xs sm:text-sm font-medium text-slate-700 hover:text-indigo-900 transition-all flex items-center justify-between group"
                    >
                      <span>{q}</span>
                      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-1" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-400">
              Select or upload a study material to view extracted concepts.
            </div>
          )}
        </div>
      </div>

      {/* Paste notes modal */}
      {showPasteModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Paste Lecture Notes or Text
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Paste rough notes, syllabus text, or excerpts. Explanation Tutor will extract the foundational mental models.
            </p>
            <form onSubmit={handleCreateFromText} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Topic Title</label>
                <input
                  type="text"
                  placeholder="e.g. Chem 101 - Acid Base Equilibria"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl text-sm border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Notes Content</label>
                <textarea
                  rows={6}
                  placeholder="Paste lecture text, formulas, or summaries here..."
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  required
                  className="w-full px-3.5 py-2 rounded-xl text-sm border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-sans"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasteModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
                >
                  Analyze & Add to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
